"""Сервис навыков, карты, Gap Analysis и простой траектории — неделя 2."""
from __future__ import annotations

import math
import uuid
from collections import defaultdict

from fastapi import HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models import (
    Profession,
    ProfessionSkill,
    ProfessionStatus,
    Skill,
    SkillStatus,
    User,
    UserSkill,
)
from app.models.enums import Level
from app.schemas.skill import (
    GapAnalysisItem,
    GapAnalysisResponse,
    ProfessionMapResponse,
    ProfessionSkillNode,
    ResourceItem,
    SkillBrief,
    TrajectoryResponse,
    TrajectoryWeek,
    UserSkillUpdate,
)


async def get_profession_or_404(db: AsyncSession, profession_id: uuid.UUID) -> Profession:
    profession = await db.get(Profession, profession_id)
    if profession is None or profession.status != ProfessionStatus.PUBLISHED:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Профессия не найдена")
    return profession


async def get_skill_or_404(db: AsyncSession, skill_id: uuid.UUID) -> Skill:
    skill = await db.get(Skill, skill_id)
    if skill is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Навык не найден")
    return skill


def _to_resource_items(raw: list | None) -> list[ResourceItem]:
    if not raw:
        return []
    result = []
    for item in raw:
        if isinstance(item, dict) and "title" in item and "url" in item:
            result.append(
                ResourceItem(
                    title=item["title"],
                    url=item["url"],
                    type=item.get("type", "article"),
                )
            )
    return result


def _to_node(
    ps: ProfessionSkill,
    user_status: str | None = None,
    self_score: int | None = None,
) -> ProfessionSkillNode:
    skill = ps.skill
    prereqs = []
    for p in ps.prerequisite_ids or []:
        try:
            prereqs.append(uuid.UUID(str(p)))
        except ValueError:
            continue
    return ProfessionSkillNode(
        id=skill.id,
        slug=skill.slug,
        title=skill.title,
        description=skill.description or "",
        difficulty=skill.difficulty,
        estimated_hours=skill.estimated_hours,
        resources=_to_resource_items(skill.resources),
        position=ps.position,
        is_core=ps.is_core,
        prerequisite_ids=prereqs,
        user_status=SkillStatus(user_status) if user_status else None,
        self_score=self_score,
    )


async def get_profession_map(
    db: AsyncSession,
    profession_id: uuid.UUID,
    user: User | None = None,
) -> ProfessionMapResponse:
    profession = await get_profession_or_404(db, profession_id)

    stmt = (
        select(ProfessionSkill)
        .where(ProfessionSkill.profession_id == profession_id)
        .options(selectinload(ProfessionSkill.skill))
        .order_by(ProfessionSkill.position)
    )
    links = list(await db.scalars(stmt))

    user_map: dict[uuid.UUID, UserSkill] = {}
    if user:
        us_rows = await db.scalars(
            select(UserSkill).where(
                UserSkill.user_id == user.id,
                UserSkill.skill_id.in_([ps.skill_id for ps in links]),
            )
        )
        user_map = {us.skill_id: us for us in us_rows}

    nodes = []
    mastered = learning = 0
    for ps in links:
        us = user_map.get(ps.skill_id)
        status_val = us.status if us else None
        score = us.self_score if us else None
        nodes.append(_to_node(ps, status_val, score))
        if status_val == SkillStatus.MASTERED.value:
            mastered += 1
        elif status_val == SkillStatus.LEARNING.value:
            learning += 1

    total = len(nodes)
    progress = round((mastered / total) * 100, 1) if total else 0.0

    return ProfessionMapResponse(
        profession_id=profession.id,
        profession_title=profession.title,
        skills=nodes,
        total_skills=total,
        mastered_count=mastered,
        learning_count=learning,
        progress_percent=progress,
    )


async def set_user_skill(
    db: AsyncSession,
    user: User,
    skill_id: uuid.UUID,
    data: UserSkillUpdate,
) -> UserSkill:
    await get_skill_or_404(db, skill_id)

    us = await db.scalar(
        select(UserSkill).where(
            UserSkill.user_id == user.id, UserSkill.skill_id == skill_id
        )
    )
    if us is None:
        us = UserSkill(user_id=user.id, skill_id=skill_id)
        db.add(us)

    us.status = data.status.value
    us.self_score = data.self_score
    await db.commit()
    await db.refresh(us)
    return us


async def list_user_skills(db: AsyncSession, user: User) -> list[UserSkill]:
    rows = await db.scalars(select(UserSkill).where(UserSkill.user_id == user.id))
    return list(rows)


async def gap_analysis(
    db: AsyncSession,
    user: User,
    profession_id: uuid.UUID,
) -> GapAnalysisResponse:
    profession = await get_profession_or_404(db, profession_id)

    stmt = (
        select(ProfessionSkill)
        .where(ProfessionSkill.profession_id == profession_id)
        .options(selectinload(ProfessionSkill.skill))
        .order_by(ProfessionSkill.position)
    )
    links = list(await db.scalars(stmt))

    us_rows = await db.scalars(
        select(UserSkill).where(
            UserSkill.user_id == user.id,
            UserSkill.skill_id.in_([ps.skill_id for ps in links] or [uuid.uuid4()]),
        )
    )
    user_map = {us.skill_id: us for us in us_rows}

    mastered: list[GapAnalysisItem] = []
    learning: list[GapAnalysisItem] = []
    missing: list[GapAnalysisItem] = []
    remaining_hours = 0

    for ps in links:
        skill = ps.skill
        us = user_map.get(ps.skill_id)
        st = SkillStatus(us.status) if us else SkillStatus.NOT_STARTED
        item = GapAnalysisItem(
            skill=SkillBrief(
                id=skill.id,
                slug=skill.slug,
                title=skill.title,
                difficulty=skill.difficulty,
                estimated_hours=skill.estimated_hours,
            ),
            status=st,
            is_core=ps.is_core,
            position=ps.position,
        )
        if st == SkillStatus.MASTERED:
            mastered.append(item)
        elif st == SkillStatus.LEARNING:
            learning.append(item)
            if skill.estimated_hours:
                remaining_hours += skill.estimated_hours
        else:
            missing.append(item)
            if skill.estimated_hours:
                remaining_hours += skill.estimated_hours

    total = len(links)
    progress = round((len(mastered) / total) * 100, 1) if total else 0.0

    return GapAnalysisResponse(
        profession_id=profession.id,
        profession_title=profession.title,
        total_skills=total,
        mastered=mastered,
        learning=learning,
        missing=missing,
        progress_percent=progress,
        estimated_remaining_hours=remaining_hours or None,
    )


async def build_trajectory(
    db: AsyncSession,
    user: User,
    profession_id: uuid.UUID,
) -> TrajectoryResponse:
    """Простая траектория: берём недостающие навыки в порядке position и режем по часам/неделям."""
    profession = await get_profession_or_404(db, profession_id)
    hours_per_week = user.hours_per_week or 6
    level = user.level

    stmt = (
        select(ProfessionSkill)
        .where(ProfessionSkill.profession_id == profession_id)
        .options(selectinload(ProfessionSkill.skill))
        .order_by(ProfessionSkill.position)
    )
    links = list(await db.scalars(stmt))

    us_rows = await db.scalars(
        select(UserSkill).where(
            UserSkill.user_id == user.id,
            UserSkill.skill_id.in_([ps.skill_id for ps in links] or [uuid.uuid4()]),
        )
    )
    mastered_ids = {
        us.skill_id
        for us in us_rows
        if us.status in (SkillStatus.MASTERED.value, SkillStatus.SKIPPED.value)
    }

    remaining = [ps for ps in links if ps.skill_id not in mastered_ids]

    weeks: list[TrajectoryWeek] = []
    current_skills: list[SkillBrief] = []
    current_hours = 0
    week_num = 1
    max_hours_per_week = max(hours_per_week, 1)

    def flush_week():
        nonlocal current_skills, current_hours, week_num
        if not current_skills:
            return
        title = f"Неделя {week_num}"
        focus = current_skills[0].title if current_skills else ""
        weeks.append(
            TrajectoryWeek(
                week=week_num,
                title=title,
                skills=list(current_skills),
                estimated_hours=current_hours,
                focus=focus,
            )
        )
        week_num += 1
        current_skills = []
        current_hours = 0

    for ps in remaining:
        skill = ps.skill
        h = skill.estimated_hours or 4
        brief = SkillBrief(
            id=skill.id,
            slug=skill.slug,
            title=skill.title,
            difficulty=skill.difficulty,
            estimated_hours=skill.estimated_hours,
        )
        if current_hours + h > max_hours_per_week and current_skills:
            flush_week()
        current_skills.append(brief)
        current_hours += h
        # Если один навык уже больше недели — всё равно кладём в одну неделю
        if current_hours >= max_hours_per_week:
            flush_week()

    flush_week()

    # Ограничим разумным горизонтом (например 24 недели)
    if len(weeks) > 24:
        weeks = weeks[:24]

    return TrajectoryResponse(
        profession_id=profession.id,
        profession_title=profession.title,
        level=level,
        hours_per_week=hours_per_week,
        total_weeks=len(weeks),
        weeks=weeks,
    )


async def recalculate_skills_count(db: AsyncSession, profession_id: uuid.UUID) -> int:
    count = await db.scalar(
        select(func.count())
        .select_from(ProfessionSkill)
        .where(ProfessionSkill.profession_id == profession_id)
    )
    profession = await db.get(Profession, profession_id)
    if profession:
        profession.skills_count = count or 0
        await db.commit()
    return count or 0
