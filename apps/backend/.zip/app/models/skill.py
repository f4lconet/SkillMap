from __future__ import annotations

import uuid


from sqlalchemy import Boolean, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, IdMixin, TimestampMixin
from app.models.enums import Level, SkillStatus, level_type


class Skill(Base, IdMixin, TimestampMixin):
    __tablename__ = "skills"

    slug: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text, default="")
    difficulty: Mapped[Level | None] = mapped_column(level_type, nullable=True)
    # [{"title": "...", "url": "...", "type": "course|article|video|book"}]
    resources: Mapped[list] = mapped_column(JSONB, default=list)
    estimated_hours: Mapped[int | None] = mapped_column(Integer, nullable=True)

    profession_links: Mapped[list[ProfessionSkill]] = relationship(
        back_populates="skill", cascade="all, delete-orphan"
    )


class ProfessionSkill(Base, IdMixin, TimestampMixin):
    __tablename__ = "profession_skills"
    __table_args__ = (
        UniqueConstraint("profession_id", "skill_id", name="uq_profession_skill"),
    )

    profession_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("professions.id", ondelete="CASCADE"), index=True
    )
    skill_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("skills.id", ondelete="CASCADE"), index=True
    )
    position: Mapped[int] = mapped_column(Integer, default=0)
    is_core: Mapped[bool] = mapped_column(Boolean, default=True)
    # Список UUID навыков-предпосылок (строки)
    prerequisite_ids: Mapped[list] = mapped_column(JSONB, default=list)

    skill: Mapped[Skill] = relationship(back_populates="profession_links", lazy="joined")
    profession: Mapped["Profession"] = relationship(  # noqa: F821
        back_populates="skill_links", lazy="joined"
    )


class UserSkill(Base, IdMixin, TimestampMixin):
    __tablename__ = "user_skills"
    __table_args__ = (
        UniqueConstraint("user_id", "skill_id", name="uq_user_skill"),
    )

    user_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    skill_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("skills.id", ondelete="CASCADE"), index=True
    )
    status: Mapped[str] = mapped_column(
        String(20), default=SkillStatus.NOT_STARTED.value, index=True
    )
    # Самооценка 1–5 (опционально)
    self_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
