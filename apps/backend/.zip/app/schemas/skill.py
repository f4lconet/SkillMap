import uuid
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from app.models.enums import Level, SkillStatus


class ResourceItem(BaseModel):
    title: str
    url: str
    type: Literal["course", "article", "video", "book", "docs"] = "article"


class SkillBrief(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    slug: str
    title: str
    difficulty: Level | None = None
    estimated_hours: int | None = None


class SkillDetail(SkillBrief):
    description: str = ""
    resources: list[ResourceItem] = Field(default_factory=list)


class ProfessionSkillNode(BaseModel):
    """Узел карты для конкретной профессии."""

    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID  # skill id
    slug: str
    title: str
    description: str = ""
    difficulty: Level | None = None
    estimated_hours: int | None = None
    resources: list[ResourceItem] = Field(default_factory=list)
    position: int = 0
    is_core: bool = True
    prerequisite_ids: list[uuid.UUID] = Field(default_factory=list)
    # Статус текущего пользователя (если авторизован)
    user_status: SkillStatus | None = None
    self_score: int | None = None


class ProfessionMapResponse(BaseModel):
    profession_id: uuid.UUID
    profession_title: str
    skills: list[ProfessionSkillNode]
    total_skills: int
    mastered_count: int = 0
    learning_count: int = 0
    progress_percent: float = 0.0


class UserSkillUpdate(BaseModel):
    status: SkillStatus
    self_score: int | None = Field(default=None, ge=1, le=5)


class UserSkillRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    skill_id: uuid.UUID
    status: SkillStatus
    self_score: int | None = None


class GapAnalysisItem(BaseModel):
    skill: SkillBrief
    status: SkillStatus
    is_core: bool
    position: int


class GapAnalysisResponse(BaseModel):
    profession_id: uuid.UUID
    profession_title: str
    total_skills: int
    mastered: list[GapAnalysisItem]
    learning: list[GapAnalysisItem]
    missing: list[GapAnalysisItem]  # not_started + skipped
    progress_percent: float
    estimated_remaining_hours: int | None = None


class TrajectoryWeek(BaseModel):
    week: int
    title: str
    skills: list[SkillBrief]
    estimated_hours: int
    focus: str = ""


class TrajectoryResponse(BaseModel):
    profession_id: uuid.UUID
    profession_title: str
    level: Level | None
    hours_per_week: int
    total_weeks: int
    weeks: list[TrajectoryWeek]
