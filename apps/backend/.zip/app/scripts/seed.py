"""Загрузка данных: python -m app.scripts.seed [--dev-users]

Идемпотентный upsert профессий и навыков.
"""
import argparse
import asyncio
import json
from pathlib import Path

from sqlalchemy import select

from app.core.config import get_settings
from app.core.database import SessionLocal, engine
from app.core.security import hash_password
from app.models import (
    Level,
    Profession,
    ProfessionSkill,
    ProfessionStatus,
    Skill,
    User,
    UserRole,
)

DATA_DIR = Path(__file__).resolve().parents[2] / "data"
PROFESSIONS_FILE = DATA_DIR / "professions.json"
SKILLS_FILE = DATA_DIR / "skills_sample.json"

DEV_USERS = [
    ("student@example.com", "Тестовый студент", "Student123", UserRole.STUDENT),
    ("editor@example.com", "Тестовый редактор", "Editor123", UserRole.EDITOR),
]

# Какие навыки к каким профессиям привязать (slug → список slug навыков по порядку)
PROFESSION_SKILL_MAP = {
    "data-scientist": [
        "python-basics",
        "data-structures",
        "sql-basics",
        "statistics",
        "pandas",
        "algorithms",
        "ml-intro",
        "git",
    ],
    "fullstack-developer": [
        "python-basics",
        "data-structures",
        "git",
        "algorithms",
        "sql-basics",
    ],
}


async def seed_professions() -> None:
    if not PROFESSIONS_FILE.exists():
        raise SystemExit(f"Нет файла данных: {PROFESSIONS_FILE}")

    items = json.loads(PROFESSIONS_FILE.read_text(encoding="utf-8"))
    async with SessionLocal() as db:
        for item in items:
            profession = await db.scalar(
                select(Profession).where(Profession.slug == item["slug"])
            )
            if profession is None:
                profession = Profession(slug=item["slug"])
                db.add(profession)

            profession.title = item["title"]
            profession.direction = item["direction"]
            profession.description = item.get("description", "")
            profession.short_description = item.get("short_description", "")
            profession.tasks = item.get("tasks") or []
            profession.suits_if = item.get("suits_if") or []
            profession.start_hint = item.get("start_hint", "")
            profession.is_priority = bool(item.get("is_priority", False))
            profession.skills_count = int(item.get("skills_count", 0))
            profession.estimated_weeks = int(item.get("estimated_weeks", 0))
            entry = item.get("entry_level")
            profession.entry_level = Level(entry) if entry else None
            profession.status = ProfessionStatus(item.get("status", "published"))
        await db.commit()
    print(f"Профессий загружено/обновлено: {len(items)}")


async def seed_skills() -> None:
    if not SKILLS_FILE.exists():
        print(f"Файл навыков не найден ({SKILLS_FILE}), пропускаем")
        return

    items = json.loads(SKILLS_FILE.read_text(encoding="utf-8"))
    async with SessionLocal() as db:
        skill_by_slug: dict[str, Skill] = {}
        for item in items:
            skill = await db.scalar(select(Skill).where(Skill.slug == item["slug"]))
            if skill is None:
                skill = Skill(slug=item["slug"])
                db.add(skill)
            skill.title = item["title"]
            skill.description = item.get("description", "")
            diff = item.get("difficulty")
            skill.difficulty = Level(diff) if diff else None
            skill.estimated_hours = item.get("estimated_hours")
            skill.resources = item.get("resources") or []
            skill_by_slug[item["slug"]] = skill
        await db.flush()

        # Привязка к профессиям
        for prof_slug, skill_slugs in PROFESSION_SKILL_MAP.items():
            profession = await db.scalar(
                select(Profession).where(Profession.slug == prof_slug)
            )
            if profession is None:
                continue
            for pos, s_slug in enumerate(skill_slugs):
                skill = skill_by_slug.get(s_slug)
                if skill is None:
                    continue
                link = await db.scalar(
                    select(ProfessionSkill).where(
                        ProfessionSkill.profession_id == profession.id,
                        ProfessionSkill.skill_id == skill.id,
                    )
                )
                if link is None:
                    link = ProfessionSkill(
                        profession_id=profession.id,
                        skill_id=skill.id,
                    )
                    db.add(link)
                link.position = pos
                link.is_core = True
                # Простые зависимости: предыдущий навык
                if pos > 0:
                    prev = skill_by_slug.get(skill_slugs[pos - 1])
                    if prev:
                        link.prerequisite_ids = [str(prev.id)]
                    else:
                        link.prerequisite_ids = []
                else:
                    link.prerequisite_ids = []

            # Обновляем счётчик
            profession.skills_count = len(skill_slugs)

        await db.commit()
    print(f"Навыков загружено/обновлено: {len(items)}")


async def seed_dev_users() -> None:
    if not get_settings().is_development:
        raise SystemExit("Тестовые пользователи только при ENVIRONMENT=development")
    async with SessionLocal() as db:
        for email, name, password, role in DEV_USERS:
            exists = await db.scalar(select(User.id).where(User.email == email))
            if exists:
                continue
            db.add(
                User(
                    email=email,
                    name=name,
                    password_hash=hash_password(password),
                    role=role,
                    is_email_verified=True,
                )
            )
        await db.commit()
    print(
        "Тестовые пользователи: "
        "student@example.com / Student123, editor@example.com / Editor123"
    )


async def main(dev_users: bool) -> None:
    await seed_professions()
    await seed_skills()
    if dev_users:
        await seed_dev_users()
    await engine.dispose()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dev-users", action="store_true")
    args = parser.parse_args()
    asyncio.run(main(args.dev_users))
